include!(concat!(env!("OUT_DIR"), "/mangled_events.rs"));
